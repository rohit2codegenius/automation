<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$csv_file = "leads.csv";
$emails_per_stage = 200;
$emails_per_domain = 30;
$domains = [
    ["smtp_host" => "smtp.domain1.com", "username" => "user1@domain1.com", "password" => "pass1"],
    ["smtp_host" => "smtp.domain2.com", "username" => "user2@domain2.com", "password" => "pass2"],
    // Weitere Domains hier hinzufügen
];

function send_email($recipient, $smtp_settings, $stage) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $smtp_settings["smtp_host"];
        $mail->SMTPAuth = true;
        $mail->Username = $smtp_settings["username"];
        $mail->Password = $smtp_settings["password"];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom($smtp_settings["username"], "Dein Name");
        $mail->addAddress($recipient);
        
        if ($stage == 1) {
            $mail->Subject = "Erstkontakt: Exklusives Angebot!";
            $mail->Body = "Hallo, wir haben ein spezielles Angebot für Sie!";
        } elseif ($stage == 2) {
            $mail->Subject = "Zweitkontakt: Erinnerungsangebot!";
            $mail->Body = "Wir möchten Sie noch einmal an unser Angebot erinnern.";
        } else {
            $mail->Subject = "Drittkontakt: Letzte Chance!";
            $mail->Body = "Dies ist unsere letzte Nachricht für Sie. Jetzt zugreifen!";
        }

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

$leads = array_map('str_getcsv', file($csv_file));
$header = array_shift($leads);

$today = date("Y-m-d");
$sent_count = [1 => 0, 2 => 0, 3 => 0];
$domain_index = 0;
$email_count = 0;

foreach ($leads as &$lead) {
    list($email, $stage, $last_sent, $next_send_date) = $lead;

    if ($sent_count[$stage] >= $emails_per_stage) continue;
    if ($next_send_date > $today) continue;

    if ($email_count >= $emails_per_domain) {
        $email_count = 0;
        $domain_index = ($domain_index + 1) % count($domains);
    }

    if (send_email($email, $domains[$domain_index], $stage)) {
        $lead[2] = $today;
        if ($stage == 1) $lead[3] = date("Y-m-d", strtotime("+3 days"));
        if ($stage == 2) $lead[3] = date("Y-m-d", strtotime("+4 days"));
        if ($stage == 3) $lead[3] = "";
        $sent_count[$stage]++;
        $email_count++;
    }
}

$file = fopen($csv_file, "w");
fputcsv($file, $header);
foreach ($leads as $lead) {
    fputcsv($file, $lead);
}
fclose($file);
?>
