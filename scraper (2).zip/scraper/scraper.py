import requests
from bs4 import BeautifulSoup
import os
import json
import csv
import re
import socket
import openai
from jinja2 import Environment, FileSystemLoader
from urllib.parse import urljoin, urlparse

# Set your OpenAI API key from an environment variable
openai.api_key = os.getenv("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")

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/91.0.4472.124 Safari/537.36'
    )
}

SERVICE_KEYWORDS = ['service', 'services', 'dienstleistungen', 'leistungen', 'angebot', 'angebote']
NAV_BLACKLIST = {
    "startseite", "homepage", "home",
    "kontakt", "contact",
    "über uns", "uber uns", "about us",
    "impressum", "imprint",
    "unsere projekte", "our projects",
    "unsere leistungen", "our services",
    "partner",
    "stellenangebote", "job offers",
    "datenschutzerklärung", "privacy policy",
    "referenzen", "references",
    "mehr", "more"
}

def download_file(url, output_path):
    try:
        response = requests.get(url, headers=HEADERS, stream=True, timeout=15)
        response.raise_for_status()
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return True
    except Exception as e:
        print(f"Error downloading {url}: {str(e)}")
        return False

def verify_email(email):
    try:
        domain = email.split('@')[-1]
        socket.gethostbyname(domain)
        return True
    except socket.error:
        return False

def verify_service(service):
    if "http://" in service or "https://" in service or "www." in service:
        return False
    if not any(c.isalpha() for c in service):
        return False
    return True

def extract_emails(soup, base_url):
    emails = set()
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    text = soup.get_text()
    for email in re.findall(email_pattern, text, re.IGNORECASE):
        if verify_email(email):
            emails.add(email)
    mailto_links = soup.select('a[href^="mailto:"]')
    for link in mailto_links:
        href = link.get('href', '')
        if 'mailto:' in href:
            email = href.split('mailto:')[-1].split('?')[0].strip()
            if re.match(email_pattern, email) and verify_email(email):
                emails.add(email)
    for script in soup.find_all('script'):
        if script.string:
            for email in re.findall(email_pattern, script.string, re.IGNORECASE):
                if verify_email(email):
                    emails.add(email)
    for meta in soup.find_all('meta', {'content': True}):
        for email in re.findall(email_pattern, meta['content'], re.IGNORECASE):
            if verify_email(email):
                emails.add(email)
    return list(emails)[:5]

def extract_services(soup):
    services = []
    headers = soup.find_all(['h2', 'h3', 'h4'])
    for header in headers:
        header_text = header.get_text(strip=True)
        if header_text.lower() in NAV_BLACKLIST:
            continue
        if any(kw in header_text.lower() for kw in SERVICE_KEYWORDS):
            sibling = header.find_next_sibling()
            while sibling and sibling.name not in ['ul', 'ol']:
                sibling = sibling.find_next_sibling()
            if sibling and sibling.name in ['ul', 'ol']:
                for li in sibling.find_all('li'):
                    text = li.get_text(strip=True)
                    if text and len(text.split()) < 10 and text.lower() not in NAV_BLACKLIST:
                        if verify_service(text) and text not in services:
                            services.append(text)
                if services:
                    break
    if not services:
        for ul in soup.find_all('ul'):
            for li in ul.find_all('li'):
                text = li.get_text(strip=True)
                if text and len(text.split()) < 10 and text.lower() not in NAV_BLACKLIST and text not in services:
                    if verify_service(text):
                        services.append(text)
    return services[:10]

def extract_data(soup, base_url):
    data = {
        'business_owner': 'Not Found',
        'services': [],
        'emails': extract_emails(soup, base_url)
    }
    possible_owner_selectors = [
        ('h1', ['owner', 'founder', 'ceo', 'geschäftsführer', 'inhaber', 'eigentümer']),
        ('h2', ['about us', 'leadership', 'uber uns', 'leitung']),
        ('div', ['owner-name', 'geschäftsführer', 'inhaber', 'eigentümer'])
    ]
    for tag, keywords in possible_owner_selectors:
        elements = soup.find_all(tag)
        for element in elements:
            text = element.get_text().strip()
            if any(kw in text.lower() for kw in keywords):
                next_elem = element.find_next(['p', 'div'])
                if next_elem:
                    data['business_owner'] = next_elem.get_text(strip=True)
                    break
        if data['business_owner'] != 'Not Found':
            break
    data['services'] = extract_services(soup)
    return data

def find_logo(soup, base_url):
    logo = None
    possible_logo_selectors = [
        ('img', {'alt': lambda x: x and 'logo' in x.lower()}),
        ('img', {'class': lambda x: x and 'logo' in x.lower()}),
        ('img', {'src': lambda x: x and 'logo' in x.lower()})
    ]
    for tag, attrs in possible_logo_selectors:
        logo = soup.find(tag, attrs)
        if logo:
            break
    if logo and logo.get('src'):
        return urljoin(base_url, logo['src'])
    return None

def generate_website_templates(data, logo_exists, output_dir):
    env = Environment(loader=FileSystemLoader('website-templates'))
    template_dir = os.path.join(output_dir, 'generated-templates')
    os.makedirs(template_dir, exist_ok=True)
    generated_files = []
    for template_file in os.listdir('website-templates'):
        if template_file.endswith('.html'):
            try:
                template = env.get_template(template_file)
                logo_url = f'/static/output/{os.path.basename(output_dir)}/logo.png' if logo_exists else ''
                rendered = template.render(
                    business_owner=data.get('business_owner', 'Business Owner'),
                    services=data.get('services', []),
                    emails=data.get('emails', []),
                    logo_url=logo_url
                )
                output_path = os.path.join(template_dir, template_file)
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(rendered)
                generated_files.append(template_file)
            except Exception as e:
                print(f"Template error: {str(e)}")
    return generated_files

def crawl_site(base_url, max_pages=50):
    visited = set()
    to_visit = [base_url]
    pages = []
    domain = urlparse(base_url).netloc
    while to_visit and len(visited) < max_pages:
        current_url = to_visit.pop(0)
        if current_url in visited:
            continue
        try:
            response = requests.get(current_url, headers=HEADERS, timeout=15)
            response.raise_for_status()
        except Exception as e:
            print(f"Error accessing {current_url}: {str(e)}")
            visited.add(current_url)
            continue
        soup = BeautifulSoup(response.content, 'html.parser')
        pages.append((current_url, soup))
        visited.add(current_url)
        for link in soup.find_all('a', href=True):
            href = link['href']
            full_url = urljoin(current_url, href)
            if urlparse(full_url).netloc == domain and full_url not in visited:
                to_visit.append(full_url)
    return pages

def main_scraper(url, output_dir, max_pages=50):
    try:
        os.makedirs(output_dir, exist_ok=True)
        pages = crawl_site(url, max_pages)
        aggregated_services = set()
        aggregated_emails = set()
        business_owner = "Not Found"
        logo_url = None

        homepage_response = requests.get(url, headers=HEADERS, timeout=15)
        homepage_response.raise_for_status()
        homepage_soup = BeautifulSoup(homepage_response.content, 'html.parser')
        homepage_data = extract_data(homepage_soup, url)
        if homepage_data.get('business_owner') and homepage_data.get('business_owner') != "Not Found":
            business_owner = homepage_data.get('business_owner')
        logo_url = find_logo(homepage_soup, url)

        for page_url, soup in pages:
            data = extract_data(soup, page_url)
            aggregated_services.update(data.get('services', []))
            aggregated_emails.update(data.get('emails', []))
            if business_owner == "Not Found" and data.get('business_owner') != "Not Found":
                business_owner = data.get('business_owner')

        aggregated_services = list(aggregated_services)[:10]
        aggregated_emails = list(aggregated_emails)[:5]
        main_service = aggregated_services[0] if aggregated_services else "N/A"

        aggregated_data = {
            'business_owner': business_owner,
            'main_service': main_service,
            'services': aggregated_services,
            'emails': aggregated_emails
        }

        logo_downloaded = False
        if logo_url:
            logo_path = os.path.join(output_dir, 'logo.png')
            logo_downloaded = download_file(logo_url, logo_path)

        files = []
        json_path = os.path.join(output_dir, 'data.json')
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(aggregated_data, f)
        files.append('data.json')

        csv_path = os.path.join(output_dir, 'data.csv')
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Business Owner', 'Main Service', 'Services', 'Emails'])
            writer.writerow([
                aggregated_data['business_owner'],
                aggregated_data['main_service'],
                ' | '.join(aggregated_data['services']),
                ' | '.join(aggregated_data['emails'])
            ])
        files.append('data.csv')
        if logo_downloaded:
            files.append('logo.png')

        template_files = generate_website_templates(aggregated_data, logo_downloaded, output_dir)
        files.extend([f'generated-templates/{f}' for f in template_files])

        return {
            'data': aggregated_data,
            'logo_url': f'/static/output/{os.path.basename(output_dir)}/logo.png' if logo_downloaded else None,
            'files': files
        }
    except requests.RequestException as e:
        return {'error': f"Connection error: {str(e)}"}
    except Exception as e:
        return {'error': f"Processing error: {str(e)}"}

def verify_data_with_chatgpt(data):
    prompt = (
        "I have scraped website data containing a business owner's name, a list of services, and contact emails. "
        "Some service items may include extraneous or invalid text (for example, a single word like 'Start' or copyright text). "
        "Please remove any items from the services list that do not represent a valid service. "
        "Return a valid JSON object with exactly three keys: 'business_owner', 'services', and 'emails', where 'services' includes only valid services.\n\n"
        f"Business Owner: {data.get('business_owner')}\n"
        f"Services: {', '.join(data.get('services', []))}\n"
        f"Emails: {', '.join(data.get('emails', []))}"
    )
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a data verification assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=150
        )
        verified_output = response['choices'][0]['message']['content'].strip()
        verified_data = json.loads(verified_output)
        return verified_data
    except Exception as e:
        print("ChatGPT verification failed:", e)
        return data

if __name__ == "__main__":
    url = "http://example.com"  # Replace with target URL for testing
    output_dir = "output_example"
    result = main_scraper(url, output_dir, max_pages=50)
    print(result)
