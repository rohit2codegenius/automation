from flask import Flask, render_template, request, send_from_directory, send_file, url_for, redirect
from scraper import main_scraper, verify_data_with_chatgpt
import os
import uuid
import shutil
import logging
import json
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'output')
app.secret_key = 'your-very-secret-key-12345'
app.logger.setLevel(logging.DEBUG)

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def validate_url(url):
    url = url.strip()
    if not url.startswith(('http://', 'https://')):
        url = f'https://{url}'
    return url

def read_urls_from_csv():
    try:
        with open('leads.csv', 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            urls = [row['url'].strip() for row in reader if row['url'].strip()]
            return urls
    except Exception as e:
        app.logger.error(f"Error reading CSV: {str(e)}")
        return []

@app.route('/', methods=['GET', 'POST'])
def index():
    # Use form input if provided; otherwise, read from CSV.
    if request.method == 'POST':
        url1 = request.form.get('url1', '').strip()
        url2 = request.form.get('url2', '').strip()
        url3 = request.form.get('url3', '').strip()
        urls = [url for url in [url1, url2, url3] if url]
    else:
        urls = read_urls_from_csv()
    
    if not urls:
        return render_template('index.html', error="No URLs provided or found in leads.csv")

    overall_id = str(uuid.uuid4())
    results = []
    
    # Scrape sites concurrently.
    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_site = {}
        for i, url in enumerate(urls, start=1):
            validated_url = validate_url(url)
            sub_id = f"{overall_id}_{i}"
            output_dir = os.path.join(app.config['UPLOAD_FOLDER'], sub_id)
            os.makedirs(output_dir, exist_ok=True)
            future = executor.submit(main_scraper, validated_url, output_dir)
            future_to_site[future] = (validated_url, sub_id, i)
            
        for future in as_completed(future_to_site):
            validated_url, sub_id, index = future_to_site[future]
            try:
                result = future.result()
                if 'error' in result:
                    app.logger.error(f"Error scraping {validated_url}: {result['error']}")
                    continue
                original_data = result['data']
                files = result['files']
                logo_url = result.get('logo_url')
                
                # Verify scraped data via ChatGPT.
                verified_data = verify_data_with_chatgpt(original_data)
                verified_json_path = os.path.join(app.config['UPLOAD_FOLDER'], sub_id, 'verified_data.json')
                with open(verified_json_path, 'w', encoding='utf-8') as f:
                    json.dump(verified_data, f)
                if 'verified_data.json' not in files:
                    files.append('verified_data.json')
                    
                results.append({
                    'source_url': validated_url,
                    'unique_id': sub_id,
                    'files': files,
                    'original_data': original_data,
                    'verified_data': verified_data,
                    'logo_url': logo_url,
                    'template_name': f'index{index}.html'
                })
            except Exception as exc:
                app.logger.error(f"Exception scraping {validated_url}: {exc}")
    
    if not results:
        return render_template('index.html', error="No data could be scraped.")
    
    # -------------------------------
    # Update leads.csv with scraped details.
    try:
        # Build mapping from validated URL to its verified data.
        scraped_mapping = {}
        for result in results:
            key = validate_url(result['source_url'])
            scraped_mapping[key] = result['verified_data']
        
        # Read the current CSV rows.
        with open('leads.csv', 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            rows = list(reader)
            fieldnames = reader.fieldnames if reader.fieldnames else ['url']
            # Ensure new columns exist.
            if 'business_owner' not in fieldnames:
                fieldnames.append('business_owner')
            if 'services' not in fieldnames:
                fieldnames.append('services')
            if 'emails' not in fieldnames:
                fieldnames.append('emails')
        
        # Update rows with scraped data.
        for row in rows:
            url = validate_url(row['url'])
            if url in scraped_mapping:
                data = scraped_mapping[url]
                row['business_owner'] = data.get('business_owner', '')
                row['services'] = ', '.join(data.get('services', []))
                row['emails'] = ', '.join(data.get('emails', []))
        
        # Write updated rows back to the CSV.
        with open('leads.csv', 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
    except Exception as e:
        app.logger.error(f"Error updating leads.csv: {str(e)}")
    # -------------------------------
    
    return render_template('result.html', results=results)

@app.route('/download/<unique_id>/<filename>')
def download_file(unique_id, filename):
    directory = os.path.join(app.config['UPLOAD_FOLDER'], unique_id)
    return send_from_directory(directory, filename)

@app.route('/download-all/<unique_id>')
def download_all(unique_id):
    directory = os.path.join(app.config['UPLOAD_FOLDER'], unique_id)
    zip_path = f"{directory}.zip"
    try:
        shutil.make_archive(directory, 'zip', directory)
        return send_file(zip_path, as_attachment=True)
    except Exception as e:
        app.logger.error(f"ZIP creation failed: {str(e)}")
        return "Error creating download archive", 500

@app.route('/view-template/<unique_id>/<template_name>')
def view_template(unique_id, template_name):
    directory = os.path.join(app.config['UPLOAD_FOLDER'], unique_id, 'generated-templates')
    return send_from_directory(directory, template_name)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error="Page not found"), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('error.html', error="Internal server error"), 500

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)
